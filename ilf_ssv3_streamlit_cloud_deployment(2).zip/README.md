# ILF SSV3 Dashboard

Controlled synthetic Design Science Research proof-of-concept dashboard for the Information Legacy Framework.

## Streamlit Community Cloud

Entrypoint: `app.py`

Dependencies are listed in `requirements.txt`.
